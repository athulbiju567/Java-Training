package com.java.laundry;

public class LaundryTest {
	public static void main(String[] args) {
		
		HondaCity city = new HondaCity(); //isA Machine
		
		Fuel petrol = new Fuel();
		Service maintainance =new Service();
		CarCost totalcost = city.cost(petrol, maintainance);

		System.out.println(totalcost);
}
}
class Car
{

}
class HondaCity extends Car { //isA

		
		
		CarCost cost(Fuel petrol, Service maintainance) {
			System.out.println("Driving..");
			drive();
			CarCost totalcost= new CarCost();
			return totalcost;
		}
		private void drive() {
			System.out.println("Drive Mode...");
		}

}
class Fuel {

}
class Petrol extends Fuel { //is

}
class Service{
	
}

class Cost{

}
class CarCost extends Cost {
//bill of electricity for that wash program of 1 hour 
//bill of water ...
//cost of washing powder for that program
double carCostAmnt=2000000; //INR

@Override
public String toString() {
	return "CarCost [CarCostAmnt=" + carCostAmnt + "]";
}
}
