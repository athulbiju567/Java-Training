package exceptiontest;

public class ExceptionTest {
	
	public static void main(String[] args) {
		System.out.println("Begin of main");
		MyCalculator mycalci=new MyCalculator();
		mycalci.divide(100, 5);
		mycalci.divide(55, 8);
		mycalci.divide(35,0);
		mycalci.divide(33, 11);
		System.out.println("End of main ");
	}

}
