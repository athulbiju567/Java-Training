package exceptiontest;

public class MyCalculator {
	void divide(int num,int den) {
		System.out.println("\t Begin divide");
		System.out.println("\t num : "+num);
		System.out.println("\t den : "+den);
		System.out.println("\t Dividing "+num+" by "+den);
		try { 
			//business logic
			int division = num / den; // 100 / 0
							//ArithmeticException ae = new ArithmeticException("/ by zero");
							//throw ae;
			
			System.out.println("\tdiv : "+division);
		}
		catch(ArithmeticException ae) {
			//error handling logic
			System.out.println("\tCannot divide "+num+ " by "+den);
		}
		System.out.println("\t End Divide");
		System.out.println("\t----------------------");
	}
}
		
//Java Virtual machine [ virtual processor ] -> physical processor 
		
		

		
		/*if(den!=0) { 
			//business logic
			int division = num / den;
			System.out.println("\tdiv : "+division);
		}
		else {
			//error handling logic
			System.out.println("\tCannot divide "+num+ " by "+den);
		}
		*/
