package com.java.exceptions.accounts;

public class InvalidOpeningBalanceException extends Exception {
	InvalidOpeningBalanceException(String str) {
		super(str);
	}
}