package com.java.exceptions;

public class CarUnLockException extends Exception {

	public CarUnLockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}