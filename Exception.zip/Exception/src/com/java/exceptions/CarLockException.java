package com.java.exceptions;

public class CarLockException extends Exception {

	public CarLockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}