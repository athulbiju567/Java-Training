// DAY 2 and 3 Assignments

package com.java.exceptionhandling;


public class ExceptionHandling {
	public static void main(String[] args) throws Exception{
		Car city = new Car();
	    Value v=new Value();
	    Age a=new Age();
	    Kms k=new Kms();
	    NOO n=new NOO();
	    Speed s=new Speed();
	    a.validateAge(5);
	    k.validateKms(50000);
	    n.validateNOO(2);
	    s.validateSpeed(50);
	    v.val();
	    city.drive();
	    city.automatictransmission();
	    city.display();
	    city.run();
	}

	}



abstract class Vehicle{
	    abstract void drive();
	}
abstract class DriveModes extends Vehicle{
	    abstract void automatictransmission();
	}

class Car extends DriveModes{
	    static String carbrand="Honda";
	     
	    
	    @Override
	    void drive() {
	        System.out.println("The Car is in Drive mode");
	    }

	    @Override
	    void automatictransmission() {
	        System.out.println("The Car is having Automatic Transmission");
	    }
	    void display() {
	        System.out.println("The car is brand is "+ carbrand);
	    }
	    final void run() {
	        System.out.println("Car is Running.....");
	    }

	}

interface finval{
	    void val();
	}
class InvalidSpeed extends Exception {
	    public InvalidSpeed(String str) {
	        super(str);
	    }
	}
class Speed {
	    final int speedlimit=120;
	    void validateSpeed(int speed) throws InvalidSpeed{
	        if(speed > 120) {
	            throw new InvalidSpeed(" OverSpeed");
	        } else {
	            System.out.println("Car Speed validated : " + speed);
	        }
	    }
	}
class Value implements finval {
	    public void val() {
	        System.out.println("The Car has a good resale value");
	    }
	}


class InvalidAgeException extends Exception {
	    public InvalidAgeException(String str) {
	        super(str);
	    }
	}

class Age {
	    void validateAge(int age) throws InvalidAgeException {
	        if (age > 20) {
	            throw new InvalidAgeException(" The Car cannot be sold");
	        } else {
	            System.out.println("Car Age validated : " + age);
	        }
	    }
	}

class InvalidKilometers extends Exception {
    public InvalidKilometers(String str) {
	        super(str);
	    }
	}

class Kms {
	    void validateKms(int kms) throws InvalidKilometers {
	        if (kms > 100000) {
	            throw new InvalidKilometers("The Car cannot be sold");
	        } else {
	            System.out.println("Car kms validated : " + kms);
	        }

	    }
	}

class InvalidOwners extends Exception {
	    public InvalidOwners(String noO) {
	        super(noO);
	    }
	}
class NOO {
	    public void validateNOO(int noofowners) throws InvalidOwners {
	        if (noofowners > 4) {
	            throw new InvalidOwners("The Car cannot be sold");
	        } else {
	            System.out.println("No. of owners validated : " + noofowners);
	        }
	    }

class Looks{}
class AccidentHistory{}
}
