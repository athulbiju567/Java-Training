package com.java.comp;

import java.util.Iterator;
import java.util.TreeSet;

public class comparat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Car> ts = new TreeSet<Car>();
		
		System.out.println("Car list is ready...");

		Car c1 = new Car("Creta",1,"Hyundai",13000,1);
		Car c2 = new Car("5 series",2,"BMW",7500,1);
		Car c3 = new Car("i20",3,"Hyundai",65000,2);
		Car c4 = new Car("800",4,"Maruti",70000,4);
		
		System.out.println("Adding the Car details");
		ts.add(c1); 
		System.out.println("----------");
		
		ts.add(c2); 
		System.out.println("----------");
		
		ts.add(c3); 
		System.out.println("----------");
		
		ts.add(c4); 
		System.out.println("----------");
		
		System.out.println("Car list is ready");
		Iterator<Car> itr = ts.iterator();
		while(itr.hasNext()) {
			Car s = itr.next();
			System.out.println("Car : "+s);
		}	
	}

}

class Car implements Comparable<Car> //isA 
{ 
	String carname;
	int id;		
	String brand;
	int kms;
	int noo;
	
	
	public int compareTo(Car s) {
		
		System.out.println("Comparing "+carname+" with "+s.carname);
		return carname.compareTo(s.carname);
	}
	public Car(String carname,int id, String brand,int kms,int noo) {
		super();
		this.carname = carname;
		this.id = id;
		this.brand = brand;
		this.kms=kms;
		this.noo=noo;
	}
	@Override
	public String toString() {
		return "Car carname : " + carname + ", id : " + id + ", brand : " + brand + ", kilometers : " + kms + ", Number of Owners=" + noo + "]";
	}
}
