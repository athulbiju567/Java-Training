package com.java.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Comparator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Car> Cars = new ArrayList<Car>();

		String choice="n";
		
		do
		{
			Scanner scan1 = new Scanner(System.in);
			System.out.println("Enter car name  : ");
			String name = scan1.nextLine(); 
			
			Scanner scan2 = new Scanner(System.in);
			System.out.println("Enter car brand : ");
			String brand = scan2.nextLine();
			
			Scanner scan3 = new Scanner(System.in);
			System.out.println("Enter car kms : ");
			int kms = scan3.nextInt();
			
			Scanner scan4 = new Scanner(System.in);
			System.out.println("Enter car noo : ");
			int noo = scan4.nextInt();
	
			Scanner scan5 = new Scanner(System.in);
			System.out.println("Enter car year  : ");
			int year = scan5.nextInt();
			
			Car temp = new Car(name,brand,kms,noo,year);
			
			Cars.add(temp);

			Scanner scan6 = new Scanner(System.in);
			System.out.println("Do you wish to add more cars ? (y/n) ");
			choice = scan6.nextLine();
			
			System.out.println("--------------------");
			
		} while(choice.equalsIgnoreCase("y"));
		
		
		Car c1 = new Car("Creta","Hyundai",15000,2,2010);
		Car c2 = new Car("Harrier","TATA",17500,2,2012);
		Car c3 = new Car("Hector","MG",22000,1,2018);
		Car c4 = new Car("Alto","Maruti",45800,4,2005);
		Car c5 = new Car("Fortuner","Toyota",36500,1,2017);
		
		
		
		Cars.add(c1);	Cars.add(c2);		Cars.add(c3);
		Cars.add(c4);	Cars.add(c5);		
	
		System.out.println("--now lets sort it based on other columns too--");
		
		int sortChoice=0;
		
		Comparator<Car> cmp = null;

		do {
			System.out.println("Sort by ");
			System.out.println("-----------");
			System.out.println("1. Name");
			System.out.println("2. Brand");
			System.out.println("3. Kilometers");
			System.out.println("4. Number of Owners");
			System.out.println("5. Year");
			System.out.println("6. Exit");
			System.out.println("-----------");
			System.out.println("Sort Choice :  ");
			Scanner scan7 = new Scanner(System.in);
			sortChoice = scan7.nextInt();
			switch(sortChoice) {
				case 1: cmp = new NameComparator(); break;
				case 2: cmp = new BrandComparator(); break;
				case 3: cmp = new KmsComparator(); break;
				case 4: cmp = new NooComparator(); break;
				case 5: cmp = new YearComparator(); break;
				case 6: System.out.println("Exiting...");
			
			}
			Collections.sort(Cars, cmp ); //going with Comparator 
			for(Car theCar : Cars) { // no iterator required
				System.out.println("Car : "+theCar);
			}
			System.out.println("====================");
		} while(sortChoice!=6);
		
	}
}

class YearComparator implements Comparator<Car> {
	public int compare(Car x, Car y) {
		System.out.println("YearComparator : comparing "+x.getYear()+" with "+y.getYear());
		return Integer.compare(x.getYear(), y.getYear());
	}
}
class NooComparator implements Comparator<Car> {
	public int compare(Car x, Car y) {
		System.out.println("Number of Owners Comparator : comparing "+x.getNoo()+" with "+y.getNoo());
		return Integer.compare(x.getNoo(), y.getNoo());
	}
}

class KmsComparator implements Comparator<Car> {
	public int compare(Car x, Car y) {
		System.out.println("YearComparator : comparing "+x.getKms()+" with "+y.getKms());
		return Integer.compare(x.getKms(), y.getKms());
	}
}
class BrandComparator implements Comparator<Car> {
	public int compare(Car x, Car y) {
		System.out.println("AlbumComparator : comparing "+x.getBrand()+" with "+y.getBrand());
		return x.getBrand()    .compareTo(    y.getBrand()     );

	}
}
class NameComparator implements Comparator<Car> {
	public int compare(Car x, Car y) {
		System.out.println("NameComparator : comparing "+x.getName()+" with "+y.getName());
		return x.getName()    .compareTo(    y.getName()     );

	}
}
class Car  implements Comparable<Car> 
{
	private String name;
	private String brand;
	private int kms;
	private int noo;
	private int year;
	
	public int compareTo(Car o) {
		return Integer.compare(o.year, year);
	}
	
	public Car(String name, String brand, int kms,int noo, int year) {
		super();
		this.name = name;
		this.brand = brand;
		this.kms = kms;
		this.noo=noo;// noo--->Number of Owners
		this.year = year;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getKms() {
		return kms;
	}

	public void setKms(int kms) {
		this.kms = kms;
	}

	public int getNoo() {
		return noo;
	}

	public void setNoo(int noo) {
		this.noo = noo;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "Car [Name: " + name + ", Brand : " + brand + ", Kilometers : " + kms + " ,Number of Owners : "+noo+", year=" + year + "]";
	}
}
