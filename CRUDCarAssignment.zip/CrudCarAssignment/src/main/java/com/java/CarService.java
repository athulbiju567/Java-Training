package com.java;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

///http://localhost:8080/CarsOnlineProject/rest/cars/getcars
@Path("/cars")
public class CarService {
	static ArrayList<Car> allCars=new ArrayList<Car>();
	public CarService() {
		System.out.println("CarService() ctor...");
		
		
		Car car1=new Car();
		car1.setCarId(1);
		car1.setCarBrand("BMW");
		car1.setCarName("350d");
		car1.setCarModel(2008);
		car1.setCarColor("Red");
		car1.setCarKms(32000);
		car1.setCarNoo(2);
		car1.setCarTransmission("Automatic");
		car1.setCarFuelType("Petrol");
		
		Car car2=new Car();
		car1.setCarId(2);
		car2.setCarBrand("Audi");
		car2.setCarName("A4");
		car2.setCarModel(2014);
		car2.setCarColor("White");
		car2.setCarKms(30000);
		car2.setCarNoo(2);
		car2.setCarTransmission("Automatic");
		car2.setCarFuelType("Petrol");
		
		Car car3=new Car();
		car1.setCarId(3);
		car3.setCarBrand("Maruti Suzuki");
		car3.setCarName("Baleno");
		car3.setCarModel(2020);
		car3.setCarColor("Blue");
		car3.setCarKms(58000);
		car3.setCarNoo(1);
		car3.setCarTransmission("Manual");
		car3.setCarFuelType("Diesel");
		
		allCars.add(car1);
		allCars.add(car2);
		allCars.add(car3);
	
	}
	
	
	@GET
	@Path("/deletecar/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public void removeCurrency(@PathParam("cid") int tempCid) {
	System.out.println("deleteCar...."+tempCid);

	for(int i=0;i<allCars.size();i++) {
	Car currency = allCars.get(i);

	if(currency.getCarId() == tempCid) {
	currency = allCars.get(i);
	allCars.remove(i);
	System.out.println("car removed...");
	break;
	}
	}

	}
	@GET
	@Path("/getcar/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Car getCar(@PathParam("cid") int tempCid) {
	System.out.println("getCar...."+tempCid);
	Car tempCar = null;
	for(Car theCar : allCars) {
	if(theCar.getCarId() == tempCid) {
	tempCar = theCar;
	break;
	}
	}
	return tempCar;
	}
	
	
	@POST
	@Path("/addcar")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addCurrency(Car newCar) {
	System.out.println("addCurrency...."+newCar);
	allCars.add(newCar);
	return Response.status(201).build();
	}
	
		
}
class Car { //POJO -plain old java object
	private int carId;
	private String carBrand;
	private String carName;
	private int carModel;
	private String carColor;
	private int carKms;
	private int carNoo;
	private String carTransmission;
	private String carFuelType;
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarBrand() {
		return carBrand;
	}
	public void setCarBrand(String carBrand) {
		this.carBrand = carBrand;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public int getCarModel() {
		return carModel;
	}
	public void setCarModel(int carModel) {
		this.carModel = carModel;
	}
	public String getCarColor() {
		return carColor;
	}
	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}
	public int getCarKms() {
		return carKms;
	}
	public void setCarKms(int carKms) {
		this.carKms = carKms;
	}
	public int getCarNoo() {
		return carNoo;
	}
	public void setCarNoo(int carNoo) {
		this.carNoo = carNoo;
	}
	public String getCarTransmission() {
		return carTransmission;
	}
	public void setCarTransmission(String carTransmission) {
		this.carTransmission = carTransmission;
	}
	public String getCarFuelType() {
		return carFuelType;
	}
	public void setCarFuelType(String carFuelType) {
		this.carFuelType = carFuelType;
	}
	
	

}
