package com.java.rest.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.java.model.Car;
import com.java.service.CarService;

@Path("/carInfo")
public class CarResource {
	CarService carService = new CarService();

	// CRUD -- CREATE operation
	@POST
	@Produces(MediaType.TEXT_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Car createCar(@FormParam("id") String id,@FormParam("name") String name,@FormParam("age") int age) {
		System.out.println("createCar() rest api");
		Car car = new Car();
		car.setId(id);
		car.setName(name);
		car.setAge(age);
		Car carResponse = carService.createCar(car);
		return carResponse;
	}

	// CRUD -- READ operation
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Car> getAllCars() {
		System.out.println("getAllCars() rest api");
		List<Car> carList = carService.getAllCars();
		return carList;
	}


	// CRUD -- UPDATE operation
	@PUT
	@Produces(MediaType.TEXT_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Car updateCar(@FormParam("id") String id,@FormParam("name") String name,@FormParam("age") int age) {
		System.out.println("updateCar() rest api");
		Car car = carService.getCarForId(id);
		car.setName(name);
		car.setAge(age);
		Car carResponse = carService.updateCar(car);
		return carResponse;
	}

	// CRUD -- DELETE operation
	@DELETE
	@Produces(MediaType.TEXT_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Car deleteeCar(@FormParam("id") String id) {
		System.out.println("deleteeCar() rest api");
		Car carResponse = carService.deleteCar(id);
		return carResponse;
	}
}
