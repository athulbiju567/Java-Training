package com.java.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.java.model.Car;

//Just to avoid DB calls in this example, Assume below data is interacting with DB
public class CarDAO {
	static HashMap<String, Car> carsMap = new HashMap<String, Car>();

	public CarDAO() {
			Car car1 = new Car();
			car1.setId("1"); 
			car1.setAge(5);
			car1.setName("Baleno");
			
			Car car2 = new Car();
			car2.setId("2");
			car2.setAge(2);
			car2.setName("Harrier");
			
			carsMap.put("1", car1);
			carsMap.put("2", car2);
	}

	public List<Car> getAllCars() {

		List<Car> carList = new ArrayList<Car>(carsMap.values());
		return carList;
	}

	public Car getCarForId(String id) {
		Car car = carsMap.get(id); //map's get method
		return car;
	}

	public Car createCar(Car car) {
		carsMap.put(car.getId(), car); //add to the map
		return carsMap.get(car.getId());//confirm from the map
	}

	public Car updateCar(Car car) {
		Car existingCar= carsMap.get(car.getId());
		if (existingCar != null) { //update 
			existingCar.setName(car.getName());
			existingCar.setAge(car.getAge());
		} else {
			carsMap.put(car.getId(), car); // save
		}
		return carsMap.get(car.getId()); //confirm the map updates
	}

	public Car deleteCar(String id) {
		Car carResponse = carsMap.remove(id);
		return carResponse;
	}

}
