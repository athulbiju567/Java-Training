package com.java.service;

import java.util.List;

import com.java.dao.CarDAO;
import com.java.model.Car;

public class CarService {
	CarDAO carDao = new CarDAO();

	public List<Car> getAllCars() {
		List<Car> carsList = carDao.getAllCars();
		return carsList;
	}

	public Car getCarForId(String id) {
		Car car = carDao.getCarForId(id);
		
		return car;
	} 

	public Car createCar(Car car) {
		Car carResponse = carDao.createCar(car);
		return carResponse;
	}

	public Car updateCar(Car car) {
		Car carResponse = carDao.updateCar(car);
		return carResponse;
	}

	public Car deleteCar(String id) {
		Car carResponse = carDao.deleteCar(id);
		return carResponse;
	}

}
