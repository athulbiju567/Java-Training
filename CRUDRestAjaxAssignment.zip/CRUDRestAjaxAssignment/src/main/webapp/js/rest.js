$(document).ready(function () {

$("#updateForm").on("submit", function(){
	
	$.ajax({
	    url: 'rest/carInfo',
	    type: 'PUT',
	    dataType: "xml",
	    data:$("#updateForm").serialize(),
	    success: function(xml) {
	    	console.log(xml);
	    	var car="";
	    	$(xml).find('Car').each(function(){
                $(this).find("id").each(function(){
                    var id = $(this).text();
                    console.log(id);
                    car=car+"ID: "+id;
                });
                $(this).find("name").each(function(){
                    var name = $(this).text();
                    console.log(name);
                    car=car+" Name: "+name;
                });
                $(this).find("age").each(function(){
                    var age = $(this).text();
                    console.log(age);
                    car=car+" Age: "+age;
                });
            });
	    	alert(car);
	    }
	});
   return true;
 })
 
 $("#deleteForm").on("submit", function(){
	$.ajax({
	    url: 'rest/carInfo',
	    type: 'DELETE',
	    dataType: "xml",
	    data:$("#deleteForm").serialize(),
	    success: function(xml) {
	    	console.log(xml);
	    	$(xml).find('Car').each(function(){
                $(this).find("id").each(function(){
                    var id = $(this).text();
                    console.log(id);
                    alert("Deleted the car with id "+id);
                });
            });
	    	
	    }
	});
   return true;
 })
});